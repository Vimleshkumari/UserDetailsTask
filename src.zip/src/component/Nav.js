import { NavLink } from "react-router-dom" 
export default function Nav(){
    return (
        <div>
            <nav className="navbar navbar-expand-md navbar-dark bg-dark sticky-top " 
            style={{opacity:0.9}}>
                <div className="collapse navbar-collapse">
                    <ul className="navbar-nav ml-auto">
                        <li className="nav-item"><NavLink className="nav-link" to='/userDetails' activeClassName='nav-link ' >User List</NavLink></li>
                        <li className="nav-item"> <NavLink className="nav-link" to='/userDetails/:Id' activeClassName='nav-link ' >User Profile</NavLink></li>
                    </ul>
                </div>
            </nav>
        </div>
    )
}