import React, {Component} from "react";
import Nav from "./Nav"
class UserId extends Component{

    
    
    render() {
        const {state1}=this.props.location
        if(!state1){
            return this.props.history.push("/userDetails/")
        }
        return (
            <div>
                <Nav/>
                
            <table  className="table table-condensed table-striped" style={{border:"5px solid black",borderCollapse: "collapse"}}>
                <thead>
               <tr>
                   <th>Id</th>
                   <th></th>
                   <th>First Name</th>
                   <th>Last Name</th>
                   <th>Email</th>   
                </tr>
      </thead>
      <tbody> 
            <tr>
                <td>{state1.id-1}</td>
                <td><img src={state1.avatar} alt="Profile" style={{borderRadius:"50%"}}/></td>
                <td>{state1.first_name}</td>
                <td>{state1.last_name}</td>
                <td>{state1.email}</td>    
            </tr>    
      </tbody>
            </table> 
        </div>)}}
                


export default UserId